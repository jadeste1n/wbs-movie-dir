import { fetchMovies } from './modules/network.js';
import { createProductCard } from './modules/ui.js';

window.addEventListener('load', 
    async () => {
        try {
        const productContainer = document.getElementById('Movie-List');
        const products = await fetchProducts();
    
        products.forEach(movie => {
            const movieCard = createProductCard(movie);
            productContainer.appendChild(movieCard);
        });
        } catch (error) {
        console.error(error);
    }
  });