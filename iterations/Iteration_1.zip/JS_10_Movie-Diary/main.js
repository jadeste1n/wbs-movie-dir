//import the fetch function
import { fetchMovies } from "./modules/network";
//import the createMovieCard function
import { createMovieCard } from './modules/ui';

// Fetch products and display them on page load -> network data
//When the page finishes loading
window.addEventListener('load', async () => {
    try { // try catch does error prevention
      const productContainer = document.getElementById('movie-list'); // get the movie List from html = product Container
      const movies = await fetchMovies(); //function only resumes with rest of code if the promise settles
        
      //if movies was correctly settled
      //for each movie out of array 'movies'
      movies.forEach(movie => {
        const productCard = createMovieCard(movie); //Each movie item retrieved by fetchMovies() is passed to createMovieCard(movie)
        productContainer.appendChild(productCard); // add this Product card to the product Conntainer from out html
      });
    } catch (error) {
      console.error(error); //Error Handling: If fetching or appending fails, the error is logged to the console.


    }
  });